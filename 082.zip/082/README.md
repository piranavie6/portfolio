# Dynamic Portfolio Template Using PHP/MYSQL


admin panel
admin id : pira@gmail.com
pass: admin123

